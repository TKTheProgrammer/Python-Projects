import tkinter as tk
from tkinter import ttk

# Function to refresh the inventory table
def refresh_table():
    for row in inventory_table.get_children():
        inventory_table.delete(row)
    with open('inventory.txt', 'r') as file:
        for line in file:
            item_name, measurement, price, qty = line.strip().split(',')
            price = price.strip('$')  # Remove the dollar sign from the price
            try:
                total_price = float(price) * int(qty)  # Calculate total price
                total_price = f"${total_price:.2f}"  # Format the total price as dollar to 2 decimals
            except ValueError:
                total_price = "Invalid Data"
            inventory_table.insert('', tk.END, values=(item_name, measurement, f"${price}", qty, total_price))

# Function to add a new inventory entry
def add_inventory():
    item_name = item_name_entry.get()
    measurement = item_measurement_entry.get()
    price = item_price_entry.get().strip('$')  # Strip the dollar sign
    quantity = item_qty_entry.get()
    with open('inventory.txt', 'a') as file:
        file.write(f'{item_name},{measurement},{price},{quantity}\n')
    refresh_table()
    clear_entries()

# Function to update an existing inventory entry
def update_inventory():
    item_name = item_name_entry.get()
    measurement = item_measurement_entry.get()
    price = item_price_entry.get().strip('$')  # Strip the dollar sign
    quantity = item_qty_entry.get()
    with open('inventory.txt', 'r') as file:
        inventory_data = file.readlines()
    with open('inventory.txt', 'w') as file:
        for line in inventory_data:
            name, meas, pr, qty = line.strip().split(',')
            if name == item_name:
                file.write(f'{item_name},{measurement},{price},{quantity}\n')
            else:
                file.write(line)
    refresh_table()
    clear_entries()

# Function to search and display an inventory entry
def search_inventory():
    search_name = item_name_entry.get()
    with open('inventory.txt', 'r') as file:
        for line in file:
            name, meas, pr, qty = line.strip().split(',')
            if name == search_name:
                result_label.config(text=f'{name} - {meas} - {pr} - {qty}')
                return
    result_label.config(text=f'{search_name} not found in inventory.')

# Function to remove an existing inventory entry
def remove_inventory():
    remove_name = item_name_entry.get()
    with open('inventory.txt', 'r') as file:
        inventory_data = file.readlines()
    with open('inventory.txt', 'w') as file:
        for line in inventory_data:
            name, meas, pr, qty = line.strip().split(',')
            if name != remove_name:
                file.write(line)
    refresh_table()
    clear_entries()

# Function to clear input fields
def clear_entries():
    item_name_entry.delete(0, tk.END)
    item_measurement_entry.delete(0, tk.END)
    item_price_entry.delete(0, tk.END)
    item_qty_entry.delete(0, tk.END)

# Function to navigate to the CRUD section
def go_to_crud(product_type):
    global selected_product_type
    selected_product_type = product_type
    product_selection_frame.pack_forget()
    crud_frame.pack()
    refresh_table()

# Initialize main window
root = tk.Tk()
root.title("Steel Products Inventory Management")

selected_product_type = None

# Predefined steel products (ensure inventory.txt starts with these)
predefined_products = [
    "Angle Iron,5m,20,50\n",
    "U Channel Iron,6m,25,30\n",
    "Paint,1L,10,100\n",
    "Welding Rods,5kg,15,200\n"
]
try:
    with open('inventory.txt', 'x') as file:
        file.writelines(predefined_products)
except FileExistsError:
    pass

# Product selection frame
product_selection_frame = tk.Frame(root)
product_selection_frame.pack()

selection_label = tk.Label(product_selection_frame, text="Select a Steel Product:")
selection_label.pack(pady=10)

products = ["Angle Iron", "U Channel Iron", "Paint", "Welding Rods"]
for product in products:
    button = tk.Button(product_selection_frame, text=product, command=lambda p=product: go_to_crud(p))
    button.pack(pady=5)

# CRUD frame
crud_frame = tk.Frame(root)

# Input fields
item_name_label = tk.Label(crud_frame, text="Steel Product:")
item_name_label.grid(row=0, column=0, padx=5, pady=5)
item_name_entry = tk.Entry(crud_frame)
item_name_entry.grid(row=0, column=1, padx=5, pady=5)

item_measurement_label = tk.Label(crud_frame, text="Measurement:")
item_measurement_label.grid(row=1, column=0, padx=5, pady=5)
item_measurement_entry = tk.Entry(crud_frame)
item_measurement_entry.grid(row=1, column=1, padx=5, pady=5)

item_price_label = tk.Label(crud_frame, text="Price ($):")
item_price_label.grid(row=2, column=0, padx=5, pady=5)
item_price_entry = tk.Entry(crud_frame)
item_price_entry.grid(row=2, column=1, padx=5, pady=5)

item_qty_label = tk.Label(crud_frame, text="Quantity:")
item_qty_label.grid(row=3, column=0, padx=5, pady=5)
item_qty_entry = tk.Entry(crud_frame)
item_qty_entry.grid(row=3, column=1, padx=5, pady=5)

# Buttons
add_button = tk.Button(crud_frame, text="Add", command=add_inventory)
add_button.grid(row=4, column=0, padx=5, pady=5)

update_button = tk.Button(crud_frame, text="Update", command=update_inventory)
update_button.grid(row=4, column=1, padx=5, pady=5)

search_button = tk.Button(crud_frame, text="Search", command=search_inventory)
search_button.grid(row=5, column=0, padx=5, pady=5)

remove_button = tk.Button(crud_frame, text="Remove", command=remove_inventory)
remove_button.grid(row=5, column=1, padx=5, pady=5)

# Inventory table
columns = ("Steel Product", "Measurement", "Price", "Quantity", "Total Price")
inventory_table = ttk.Treeview(crud_frame, columns=columns, show='headings')
for col in columns:
    inventory_table.heading(col, text=col)
inventory_table.grid(row=6, column=0, columnspan=2, padx=5, pady=5)

# Result label
result_label = tk.Label(crud_frame, text="")
result_label.grid(row=7, column=0, columnspan=2, padx=5, pady=5)

# Start the application
root.mainloop()
